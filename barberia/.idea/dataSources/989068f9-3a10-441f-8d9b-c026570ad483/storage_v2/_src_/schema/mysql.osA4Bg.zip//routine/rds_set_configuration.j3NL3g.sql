create
    definer = rdsadmin@localhost procedure rds_set_configuration(IN name varchar(30), IN value int)
BEGIN
   DECLARE sql_logging BOOLEAN;

   IF name = 'binlog retention hours' AND value NOT BETWEEN 1 AND 168 THEN
       SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'For binlog retention hours the value must be between 1 and 168 inclusive or be NULL';
   END IF;

   SELECT @@sql_log_bin INTO sql_logging;
   SET @@sql_log_bin = OFF;
   UPDATE mysql.rds_configuration
   SET mysql.rds_configuration.value = value
   WHERE BINARY mysql.rds_configuration.name = BINARY name;
   SET @@sql_log_bin = sql_logging;
END;

