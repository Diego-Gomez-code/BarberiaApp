create
    definer = rdsadmin@localhost procedure rds_disable_gsh_collector()
begin
  DECLARE sql_logging BOOLEAN;
  select @@sql_log_bin into sql_logging;
  set @@sql_log_bin=off;
  alter event ev_rds_gsh_collector DISABLE;
  select 'Collector Disabled' as `Success`;
  set @@sql_log_bin=sql_logging;
 end;

